
document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("bmiForm").addEventListener("submit", function (e) {
      e.preventDefault();
      calculateBMI();
    });
  
    function calculateBMI() {
      var weight = parseFloat(document.getElementById("weight").value);
      var height = parseFloat(document.getElementById("height").value) / 100;
      var bmi = weight / (height * height);
      document.getElementById("bmiResult").innerHTML = "Your BMI is: " + bmi.toFixed(2);
    }
  });
  
  // email function

document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("bookingForm").addEventListener("submit", function (e) {
        e.preventDefault();
        sendBookingConfirmation();
    });

    function sendBookingConfirmation() {
        var templateId = 'template_gvve331'; 
        var userId = 'AILcEuNB-R5ULqCCG'; 

        var firstName = document.getElementById("firstName").value;
        var lastName = document.getElementById("lastName").value;
        var email = document.getElementById("email").value;
        var appointmentDate = document.getElementById("appointmentDate").value;

        var bookingId = generateBookingId();

        var templateParams = {
            firstName: firstName,
            lastName: lastName,
            email: email,
            appointmentDate: appointmentDate,
            bookingId: bookingId
        };

        emailjs.send('service_wai16cl', templateId, templateParams, userId)
            .then(function (response) {
                console.log('Email sent successfully:', response);
                alert('Booking confirmation email sent successfully!');
            }, function (error) {
                console.error('Error sending email:', error);
                alert('Failed to send booking confirmation email. Please try again later.');
            });
    }


    function generateBookingId() {
        var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        var bookingId = '';
        for (var i = 0; i < 4; i++) {
            bookingId += characters.charAt(Math.floor(Math.random() * characters.length));
        }
        return bookingId;
    }
});
